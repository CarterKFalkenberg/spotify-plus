import { mock as fast } from './fast-tagging-fixtures.ts';
import type { Page } from '@playwright/test';
const revision={library:'1',annotations:'1'};
const artistId=(n:number)=>String(n).padStart(22,'a');
const track=(n:number)=>({trackKey:String(n).padStart(64,'0'),tagIds:[],metadata:{title:`Fictional song ${String(n).padStart(3,'0')}`,artists:[{id:artistId((n%180)+1),name:`Studio ${String((n%180)+1).padStart(3,'0')}`}],album:`Field notes ${Math.floor(n/10)+1}`,releaseDate:'1994',durationMs:181000,explicit:false,artworkUrl:`https://i.scdn.co/image/synthetic${n%18+1}`,spotifyUrl:'https://open.spotify.com/track/aaaaaaaaaaaaaaaaaaaaaa',playableUri:'spotify:track:aaaaaaaaaaaaaaaaaaaaaa',likedAt:'2026-10-11T12:00:00Z',removedAt:null,acknowledgedAt:null}});
export async function stress(page:Page){
 const state=await fast(page,{intercept:async(route,path,body)=>{
  if(path==='/api/library/status'||path==='/api/library/sync'){await route.fulfill({json:{revision,initialSyncComplete:true,syncPhase:'idle',importedCount:3000,reportedTotal:3000,activeCount:3000,untaggedCount:2500,newCount:2,lastCompletedAt:'2026-10-11T12:00:00Z',blockedBy:null}});return true;}
  if(path==='/api/library/search'){
   const start=Number(body.cursor?.replace('offset_', '')??0),limit=body.limit??50;
   if(body.groupBy){const total=body.groupBy==='decade'?8:180;const indices=Array.from({length:Math.min(limit,total-start)},(_,i)=>start+i+1);await route.fulfill({json:{revision,groupBy:body.groupBy,totalTracks:3000,totalGroups:total,nextCursor:start+limit<total?'offset_'+String(start+limit).padStart(16,'0'):null,groups:indices.map(n=>({value:body.groupBy==='artist'?artistId(n):body.groupBy==='album'?`album:${String(n).padStart(64,'a')}`:String(1950+n*10),artistId:artistId(n),name:body.groupBy==='artist'?`Studio ${String(n).padStart(3,'0')}`:body.groupBy==='album'?`Field notes ${n}`:`${1950+n*10}s`,trackCount:Math.max(8,48-n),taggedCount:n%8,artworkUrl:body.groupBy==='artist'?`https://i.scdn.co/image/profile${n}`:body.groupBy==='album'?`https://i.scdn.co/image/synthetic${n%18+1}`:null,selection:{kind:'filter',filter:{...body.filter,...(body.groupBy==='artist'?{artistId:artistId(n)}:body.groupBy==='album'?{album:`album:${String(n).padStart(64,'a')}`}:{decade:1950+n*10})},expectedRevision:revision}}))}});return true;}
   await route.fulfill({json:{revision,groupBy:null,totalTracks:3000,nextCursor:start+limit<3000?'offset_'+String(start+limit).padStart(16,'0'):null,tracks:Array.from({length:Math.min(limit,3000-start)},(_,i)=>track(start+i+1))}});return true;
  }return false;
 }});
 await page.route('**/image/profile*',async route=>{const n=Number(new URL(route.request().url()).pathname.match(/profile(\d+)/)?.[1]??1);const colors=['#b1b6c3','#d5bfa8','#9eb5b0'];const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300"><rect width="300" height="300" fill="${colors[n%3]}"/><circle cx="150" cy="112" r="54" fill="#46545e"/><path d="M38 300v-30a112 112 0 0 1 224 0v30" fill="#46545e"/><text x="150" y="285" fill="white" font-size="16" text-anchor="middle" font-family="sans-serif">FICTIONAL STUDIO ${n}</text></svg>`;await route.fulfill({contentType:'image/svg+xml',body:svg});});
 return state;
}

import {mock as originalCore} from './core-fixtures.ts';
import {mock as originalFast} from './fast-tagging-fixtures.ts';
import type {Page} from '@playwright/test';
const id=(n:number)=>`${String(n).padStart(8,'0')}-aaaa-4aaa-8aaa-aaaaaaaaaaaa`;
const names=['Chill','chillout','mood:soft','Driving','Instrumental','Low energy','Focus','Evening','Favourites'];
const tags=names.map((name,i)=>({id:id(i+1),name,activeTrackCount:36-i*3,lastUsedAt:'2026-10-11T12:00:00Z'}));
export async function fast(page:Page){return originalFast(page,{intercept:async(route,path,body)=>{
 if(path==='/api/tags'||path==='/api/tags/vocabulary'){await route.fulfill({json:{revision:{library:'1',annotations:'1'},hasMore:false,nextCursor:null,tags}});return true;}
 if(path==='/api/tags/lookup'){await route.fulfill({json:{revision:{library:'1',annotations:'1'},tags:body.tagIds.map((x:string)=>tags.find(t=>t.id===x))}});return true;}
 return false;
}});}
export async function core(page:Page){return originalCore(page,async(route,path)=>{
 if(path==='/api/playlists'&&route.request().method()==='GET'){
  const base={revision:'1',spotifyUrl:'https://open.spotify.com/playlist/aaaaaaaaaaaaaaaaaaaaaa',query:{version:1,root:{op:'tag',tagId:id(1)}},retention:'month',createdAt:'2026-10-11T12:00:00Z',expiresOn:'2026-11-11',trackCount:2,blockedBy:null};
  await route.fulfill({json:{playlists:[{...base,id:'000001f5-aaaa-4aaa-8aaa-aaaaaaaaaaaa',name:'A slower way home',status:'ready',artworkUrl:'https://i.scdn.co/image/synthetic1'},{...base,id:'000001f6-aaaa-4aaa-8aaa-aaaaaaaaaaaa',name:'Sunday, with the windows open',status:'pending',artworkUrl:null},{...base,id:'000001f7-aaaa-4aaa-8aaa-aaaaaaaaaaaa',name:'Small hours / a longer fictional playlist title',status:'incomplete',blockedBy:'unavailable',artworkUrl:'https://i.scdn.co/image/synthetic3'}],nextCursor:null,lastCleanupAt:new Date().toISOString(),cleanupBlockedBy:null}});return true;
 }return false;
});}

import type {Page,Route} from '@playwright/test';
const id = (n: number) =>
  `${String(n).padStart(8, "0")}-aaaa-4aaa-8aaa-aaaaaaaaaaaa`;
const album = `album:${"a".repeat(64)}`;
const base = {
  membership: "active",
  search: "",
  untagged: false,
  newOnly: false,
  artistId: null,
};
const makeTag = (n: number, name: string) => ({
  id: id(n),
  name,
  activeTrackCount: n === 1 ? 12 : 6,
  lastUsedAt: "2026-10-11T12:00:00Z",
});
const tags = [
  makeTag(1, "Chill"),
  makeTag(2, "chillout"),
  makeTag(3, "mood:soft"),
];
const makeTrack = (n: number) => ({
  trackKey: String(n).padStart(64, "0"),
  tagIds: [] as string[],
  metadata: {
    title: ["After the rain", "Soft circuit", "Night swim", "Room for tomorrow", "Paper satellites", "Low tide", "Almost home", "Velvet transit", "Slow morning", "Colour field", "Another season", "Through the window", "Blue hour", "A little further", "Open water", "Quiet city", "Southbound", "Good company"][(n - 1) % 18],
    artists: [{ id: "aaaaaaaaaaaaaaaaaaaaaa", name: "Studio North" }],
    album: ["Small hours", "Field notes", "Elsewhere"][(n - 1) % 3],
    releaseDate: "1994",
    durationMs: 181000,
    explicit: false,
    artworkUrl: `https://i.scdn.co/image/synthetic${n}`,
    spotifyUrl: "https://open.spotify.com/track/aaaaaaaaaaaaaaaaaaaaaa",
    playableUri: "spotify:track:aaaaaaaaaaaaaaaaaaaaaa",
    likedAt: "2026-10-11T12:00:00Z",
    removedAt: null,
    acknowledgedAt: null,
  },
});
async function mock(
  page: Page,
  options: {
    failAction?: boolean;
    stale?: boolean;
    intercept?: (route: Route, path: string, body: any) => Promise<boolean>;
  } = {},
) {
  const tracks = Array.from({length:18},(_,i)=>makeTrack(i+1)),
    calls: { path: string; body: any }[] = [];
  let annotation = 1;
  const revision = () => ({
    library: options.stale ? "2" : "1",
    annotations: String(annotation),
  });
  await page.route("**/*", async (route) => {
    const url = new URL(route.request().url());
    if (url.hostname === "i.scdn.co") {
      const n = Number(url.pathname.match(/synthetic(\d+)/)?.[1] ?? 1);
      const palettes = [["#c6dcbd","#2b4b40","#e8a06f"],["#293342","#a7beca","#c36c42"],["#d7b98b","#874b3c","#f0dfc5"]];
      const [base,ink,detail]=palettes[(n-1)%3];
      const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="640" height="640" viewBox="0 0 640 640"><rect width="640" height="640" fill="${base}"/><path d="M0 390 Q200 ${80+n*5} 350 350 T640 240 V640 H0Z" fill="${ink}"/><circle cx="${360+n*3}" cy="190" r="95" fill="${detail}"/><path d="M0 480 Q200 330 420 480 T640 390 V640 H0Z" fill="${detail}" opacity=".7"/><text x="40" y="58" font-family="sans-serif" font-size="18" letter-spacing="4" fill="${ink}">STUDIO NORTH / STUDY ${String(n).padStart(2,'0')}</text></svg>`;
      return route.fulfill({contentType:"image/svg+xml",body:svg});
    }
    if (url.origin !== (process.env.PROOF_ORIGIN ?? "http://127.0.0.1:4174")) return route.abort();
    if (!url.pathname.startsWith("/api/")) return route.continue();
    const path = url.pathname,
      body = route.request().postData() ? route.request().postDataJSON() : null;
    calls.push({ path, body });
    if (options.intercept && (await options.intercept(route, path, body)))
      return;
    let json: any;
    if (path === "/api/session")
      json = {
        authenticated: true,
        connection: "connected",
        authorizationDeadline: "2027-04-11T12:00:00Z",
        reconnectWarning: null,
      };
    else if (path === "/api/library/status" || path === "/api/library/sync")
      json = {
        revision: revision(),
        initialSyncComplete: true,
        syncPhase: "idle",
        importedCount: 18,
        reportedTotal: 18,
        activeCount: 18,
        untaggedCount: tracks.filter((t) => !t.tagIds.length).length,
        newCount: 2,
        lastCompletedAt: "2026-10-11T12:00:00Z",
        blockedBy: null,
      };
    else if (path === "/api/library/search")
      json = body.groupBy
        ? {
            revision: revision(),
            groupBy: body.groupBy,
            totalTracks: 18,
            totalGroups: 1,
            nextCursor: null,
            groups: [
              {
                artistId: "aaaaaaaaaaaaaaaaaaaaaa",
                value:
                  body.groupBy === "album"
                    ? album
                    : body.groupBy === "decade"
                      ? "1990"
                      : "aaaaaaaaaaaaaaaaaaaaaa",
                name:
                  body.groupBy === "album"
                    ? "Album unavailable"
                    : body.groupBy === "decade"
                      ? "1990s"
                      : "Synthetic Artist",
                trackCount: 18,
                taggedCount: 0,
                selection: {
                  kind: "filter",
                  filter: {
                    ...body.filter,
                    ...(body.groupBy === "album"
                      ? { album }
                      : body.groupBy === "decade"
                        ? { decade: 1990 }
                        : { artistId: "aaaaaaaaaaaaaaaaaaaaaa" }),
                  },
                  expectedRevision: revision(),
                },
              },
            ],
          }
        : {
            revision: revision(),
            groupBy: null,
            totalTracks: tracks.length,
            nextCursor: null,
            tracks: tracks.filter(
              (t) => !body.filter.untagged || !t.tagIds.length,
            ),
          };
    else if (path === "/api/library/facets")
      json = {
        revision: revision(),
        facet: body.facet,
        totalOptions: 1,
        nextCursor: null,
        options: [
          {
            value:
              body.facet === "album"
                ? album
                : body.facet === "decade"
                  ? "1990"
                  : "aaaaaaaaaaaaaaaaaaaaaa",
            name:
              body.facet === "album"
                ? "Album unavailable"
                : body.facet === "decade"
                  ? "1990s"
                  : "Synthetic Artist",
            trackCount: 18,
          },
        ],
      };
    else if (path === "/api/library/acknowledge")
      json = { revision: revision(), changedCount: body.trackKeys.length };
    else if (path === "/api/tags")
      json = {
        revision: revision(),
        hasMore: false,
        tags: url.searchParams.get("search") === "fresh" ? [] : tags,
      };
    else if (path === "/api/tags/vocabulary")
      json = {
        revision: revision(),
        hasMore: false,
        nextCursor: null,
        tags: body.sort === "unused" ? [] : tags,
      };
    else if (path === "/api/tags/lookup")
      json = {
        revision: revision(),
        tags: body.tagIds.map((x: string) => tags.find((t) => t.id === x)),
      };
    else if (path === "/api/tags/selection")
      json = {
        revision: revision(),
        selectedCount:
          body.selection.kind === "tracks"
            ? body.selection.trackKeys.length
            : 18,
        tags: body.tagIds.map((tagId: string) => {
          const t = tags.find((t) => t.id === tagId)!;
          const selectedCount =
            body.selection.kind === "tracks"
              ? body.selection.trackKeys.length
              : 3;
          return {
            tag: t,
            assignedCount: t.id === id(1) ? 1 : 0,
            state:
              t.id === id(1) ? (selectedCount === 1 ? "all" : "some") : "none",
          };
        }),
      };
    else if (path === "/api/tag-actions") {
      if (options.failAction)
        return route.fulfill({
          status: 409,
          json: { error: "stale_revision" },
        });
      const t =
        tags.find((t) => t.id === body.tagId) ?? makeTag(4, body.tagName);
      for (const row of tracks)
        if (
          body.selection.kind === "filter" ||
          body.selection.trackKeys.includes(row.trackKey)
        )
          row.tagIds =
            body.action === "add"
              ? [...new Set([...row.tagIds, t.id])]
              : row.tagIds.filter((x) => x !== t.id);
      annotation++;
      json = {
        actionId: id(50),
        selectedCount: 1,
        changedCount: 1,
        tag: t,
        revision: revision(),
      };
    } else if (path.endsWith("/undo")) {
      tracks[0]!.tagIds = [];
      annotation++;
      json = {
        actionId: id(50),
        restoredCount: 1,
        skippedCount: 1,
        revision: revision(),
      };
    } else if (path === "/api/tags/manage-preview")
      json = {
        revision: revision(),
        assignmentCount: 12,
        activeTrackCount: 7,
        unionCount: 14,
        collisionTag:
          body.action === "rename" && body.name.toLowerCase() === "chill"
            ? tags[0]
            : null,
      };
    else if (path === "/api/tags/manage") {
      annotation++;
      json = {
        revision: revision(),
        assignmentCount: 12,
        activeTrackCount: 7,
        unionCount: 14,
        collisionTag: null,
        actionId: id(51),
        changedCount: 4,
        tag: body.action === "delete" ? null : tags[0],
      };
    } else if (path === "/api/playlists")
      json = {
        playlists: [],
        nextCursor: null,
        lastCleanupAt: null,
        cleanupBlockedBy: null,
      };
    else throw Error(`Unexpected synthetic route ${path}`);
    await route.fulfill({ json });
  });
  return calls;
}

export { mock };

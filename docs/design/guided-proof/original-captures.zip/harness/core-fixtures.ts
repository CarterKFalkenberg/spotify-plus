import type {Page,Route} from '@playwright/test';
const id = (n: number) =>
  `${n.toString(16).padStart(8, "0")}-aaaa-4aaa-8aaa-aaaaaaaaaaaa`;
const revision = { library: "1", annotations: "1" };
const tag = (n = 1) => ({
  id: id(n),
  name: `Synthetic tag ${n}`,
  activeTrackCount: 3,
  lastUsedAt: null,
});
const filter = {
  membership: "active",
  search: "",
  untagged: false,
  newOnly: false,
  artistId: null,
};
const group = {
  artistId: "aaaaaaaaaaaaaaaaaaaaaa",
  name: "Studio North",
  trackCount: 3,
  taggedCount: 0,
  selection: {
    kind: "filter",
    filter: { ...filter, artistId: "aaaaaaaaaaaaaaaaaaaaaa" },
    expectedRevision: revision,
  },
};
const track = (n = 1, tagIds: string[] = [], playable = true) => ({
  trackKey: n.toString(16).padStart(64, "0"),
  tagIds,
  metadata: {
    title: ["After the rain", "Soft circuit", "Night swim", "Room for tomorrow", "Paper satellites", "Low tide", "Almost home", "Velvet transit", "Slow morning", "Colour field", "Another season", "Through the window", "Blue hour", "A little further", "Open water", "Quiet city", "Southbound", "Good company"][(n - 1) % 18],
    artists: [{ id: "aaaaaaaaaaaaaaaaaaaaaa", name: "Studio North" }],
    album: ["Small hours", "Field notes", "Elsewhere"][(n - 1) % 3],
    releaseDate: "2026",
    durationMs: 180000,
    explicit: false,
    artworkUrl: `https://i.scdn.co/image/synthetic${n}`,
    spotifyUrl: "https://open.spotify.com/track/aaaaaaaaaaaaaaaaaaaaaa",
    playableUri: playable ? "spotify:track:aaaaaaaaaaaaaaaaaaaaaa" : null,
    likedAt: "2026-10-11T12:00:00Z",
    removedAt: null,
    acknowledgedAt: null,
  },
});
const status = {
  revision,
  initialSyncComplete: true,
  syncPhase: "idle",
  importedCount: 3,
  reportedTotal: 3,
  activeCount: 3,
  untaggedCount: 3,
  newCount: 2,
  lastCompletedAt: "2026-10-11T12:00:00Z",
  blockedBy: null,
};
const playlist = (n = 1) => ({
  id: id(500 + n),
  revision: "1",
  name: `Synthetic playlist ${n}`,
  spotifyUrl: "https://open.spotify.com/playlist/aaaaaaaaaaaaaaaaaaaaaa",
  query: { version: 1, root: { op: "tag", tagId: id(1) } },
  retention: "month",
  createdAt: "2026-10-11T12:00:00Z",
  expiresOn: "2026-11-11",
  trackCount: 2,
  status: "ready",
  blockedBy: null,
});
type Override = (route: Route, path: string) => Promise<boolean>;
async function mock(
  page: Page,
  override?: Override,
  context: {
    revision?: () => typeof revision;
    tracks?: () => ReturnType<typeof track>[];
  } = {},
) {
  const calls: { path: string; body: any }[] = [];
  await page.route("**/*", async (route) => {
    const url = new URL(route.request().url());
    if (url.hostname === "i.scdn.co") {
      const n = Number(url.pathname.match(/synthetic(\d+)/)?.[1] ?? 1);
      const palettes = [["#c6dcbd","#2b4b40","#e8a06f"],["#293342","#a7beca","#c36c42"],["#d7b98b","#874b3c","#f0dfc5"]];
      const [base,ink,detail]=palettes[(n-1)%3];
      const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="640" height="640" viewBox="0 0 640 640"><rect width="640" height="640" fill="${base}"/><path d="M0 390 Q200 ${80+n*5} 350 350 T640 240 V640 H0Z" fill="${ink}"/><circle cx="${360+n*3}" cy="190" r="95" fill="${detail}"/><path d="M0 480 Q200 330 420 480 T640 390 V640 H0Z" fill="${detail}" opacity=".7"/><text x="40" y="58" font-family="sans-serif" font-size="18" letter-spacing="4" fill="${ink}">STUDIO NORTH / STUDY ${String(n).padStart(2,'0')}</text></svg>`;
      return route.fulfill({contentType:"image/svg+xml",body:svg});
    }
    if (url.origin !== (process.env.PROOF_ORIGIN ?? "http://127.0.0.1:4174")) return route.abort();
    if (!url.pathname.startsWith("/api/")) return route.continue();
    const path = url.pathname;
    calls.push({
      path,
      body: route.request().postData() ? route.request().postDataJSON() : null,
    });
    if (override && (await override(route, path))) return;
    const responseRevision = context.revision?.() ?? revision;
    const responseTracks = context.tracks?.() ?? [track(1, [id(1)]), track(2)];
    let json: any;
    if (path === "/api/session")
      json = {
        authenticated: true,
        connection: "connected",
        authorizationDeadline: "2027-04-11T12:00:00Z",
        reconnectWarning: null,
      };
    else if (path === "/api/library/status" || path === "/api/library/sync")
      json = { ...status, revision: responseRevision };
    else if (path === "/api/library/search") {
      const body = route.request().postDataJSON();
      json = body.groupBy
        ? {
            groupBy: "artist",
            totalGroups: 1,
            groups: [
              {
                ...group,
                selection: {
                  ...group.selection,
                  expectedRevision: responseRevision,
                },
              },
            ],
            totalTracks: 3,
            revision: responseRevision,
            nextCursor: null,
          }
        : {
            groupBy: null,
            tracks: responseTracks,
            totalTracks: 2,
            revision: responseRevision,
            nextCursor: null,
          };
    } else if (path === "/api/library/facets")
      json = {
        facet: route.request().postDataJSON().facet,
        revision: responseRevision,
        options: [],
        totalOptions: 0,
        nextCursor: null,
      };
    else if (path === "/api/tags/selection") {
      const body = route.request().postDataJSON();
      if (
        JSON.stringify(body.expectedRevision) !==
          JSON.stringify(responseRevision) ||
        (body.selection.kind === "filter" &&
          JSON.stringify(body.selection.expectedRevision) !==
            JSON.stringify(responseRevision))
      ) {
        await route.fulfill({ status: 409, json: { error: "stale_revision" } });
        return;
      }
      const selectedTracks =
        body.selection.kind === "tracks"
          ? responseTracks.filter((t) =>
              body.selection.trackKeys.includes(t.trackKey),
            )
          : responseTracks;
      const selectedCount =
        body.selection.kind === "tracks" ? body.selection.trackKeys.length : 3;
      json = {
        revision: responseRevision,
        selectedCount,
        tags: body.tagIds.map((value: string) => {
          const assignedCount = selectedTracks.filter((t) =>
            t.tagIds.includes(value),
          ).length;
          return {
            tag: tag(parseInt(value.slice(0, 8), 16)),
            assignedCount,
            state:
              assignedCount === 0
                ? "none"
                : assignedCount === selectedCount
                  ? "all"
                  : "some",
          };
        }),
      };
    } else if (path === "/api/tags/vocabulary")
      json = {
        revision: responseRevision,
        tags: [tag()],
        hasMore: false,
        nextCursor: null,
      };
    else if (path === "/api/tags")
      json = { tags: [tag()], hasMore: false, revision: responseRevision };
    else if (path === "/api/tags/lookup")
      json = {
        tags: route
          .request()
          .postDataJSON()
          .tagIds.map((value: string) => tag(parseInt(value.slice(0, 8), 16))),
        revision: responseRevision,
      };
    else if (path === "/api/tag-actions") {
      const body = route.request().postDataJSON();
      if (
        body.selection.kind === "filter" &&
        JSON.stringify(body.selection.expectedRevision) !==
          JSON.stringify(responseRevision)
      ) {
        await route.fulfill({ status: 409, json: { error: "stale_revision" } });
        return;
      }
      json = {
        actionId: id(400),
        selectedCount: 3,
        changedCount: 2,
        revision: {
          ...responseRevision,
          annotations: String(BigInt(responseRevision.annotations) + 1n),
        },
        tag: {
          ...tag(),
          name: route.request().postDataJSON().tagName ?? tag().name,
        },
      };
    } else if (path.endsWith("/undo"))
      json = {
        actionId: id(400),
        restoredCount: 1,
        skippedCount: 1,
        revision: responseRevision,
      };
    else if (path === "/api/query/preview")
      json = {
        query: route.request().postDataJSON().query,
        revision: responseRevision,
        generationReady: true,
        matchedCount: 3,
        playableCount: 2,
        excludedCount: 1,
        durationMs: 360000,
        tracks: [track(1), track(2), track(3, [], false)],
        nextCursor: null,
      };
    else if (path === "/api/playlists" && route.request().method() === "GET")
      json = {
        playlists: [playlist()],
        nextCursor: null,
        lastCleanupAt: new Date().toISOString(),
        cleanupBlockedBy: null,
      };
    else if (path === "/api/playlists" || path.endsWith("/actions"))
      json = {
        requestId: route.request().postDataJSON().requestId,
        playlist: { ...playlist(), status: "pending" },
      };
    else throw new Error(`Unexpected synthetic route ${path}`);
    await route.fulfill({ json });
  });
  return calls;
}

export { mock };
